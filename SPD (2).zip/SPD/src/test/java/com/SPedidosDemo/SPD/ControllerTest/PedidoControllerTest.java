package com.SPedidosDemo.SPD.ControllerTest;

import com.SPedidosDemo.SPD.Controller.PedidoController;
import com.SPedidosDemo.SPD.Model.PedidoModel;
import com.SPedidosDemo.SPD.Service.PedidoService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.springframework.http.MediaType;

@WebMvcTest(PedidoController.class)
class PedidoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PedidoService pedidoService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Prueba la creación exitosa de un pedido.
     * Verifica:
     * - Código de respuesta HTTP 200 (OK)
     * - El cuerpo de la respuesta contiene el código de seguimiento correcto
     * - El servicio fue invocado correctamente
     */
    @Test
    void testCrearPedido_retorna201() throws Exception {
        // Configuración
        PedidoModel nuevoPedido = new PedidoModel(null, "XYZ001", 
        "RECIBIDO", null, "cliente123");
        when(pedidoService.crearPedido(any())).thenReturn(nuevoPedido);

        // Ejecución y Verificación
        mockMvc.perform(post("/api/pedidos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevoPedido)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.codigoSeguimiento").value("XYZ001"));
    }

    /**
     * Prueba la obtención de pedidos por estado.
     * Verifica:
     * - Código de respuesta HTTP 200 (OK)
     * - La respuesta contiene una lista con pedidos en el estado solicitado
     * - El servicio fue invocado con el parámetro correcto
     */
    @Test
    void testListarPorEstado() throws Exception {
        // Configuración
        PedidoModel pedido = new PedidoModel(1L, "ABC123", "RECIBIDO", null, "cliente123");
        when(pedidoService.listarPorEstado("RECIBIDO")).thenReturn(List.of(pedido));

        // Ejecución y Verificación
        mockMvc.perform(get("/api/pedidos/estado/RECIBIDO"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].estado").value("RECIBIDO"));
    }

    /**
     * Prueba la búsqueda de un pedido con código inexistente.
     * Verifica:
     * - Código de respuesta HTTP 404 (Not Found)
     * - El mensaje de error es el esperado
     * - El servicio lanza la excepción adecuada
     */
    @Test
    void testBuscarPorCodigo_noExiste_retorna404() throws Exception {
        // Configuración
        String codigoInexistente = "NOEXISTE";
        when(pedidoService.buscarPorCodigo(codigoInexistente))
                .thenThrow(new RuntimeException("No se encontró el pedido"));

        // Ejecución y Verificación
        mockMvc.perform(get("/api/pedidos/{codigoSeguimiento}", codigoInexistente))
                .andExpect(status().isNotFound())
                .andExpect(content().string("No se encontró el pedido"));
    }

    /**
     * Prueba la creación de pedido con datos inválidos.
     * Verifica:
     * - Código de respuesta HTTP 400 (Bad Request)
     * - La validación falla cuando faltan campos obligatorios
     * - El servicio no es invocado
     */
    @Test
    void testCrearPedido_datosInvalidos_retorna400() throws Exception {
        // Configuración (pedido sin código de seguimiento)
        PedidoModel pedidoInvalido = new PedidoModel();

        // Ejecución y Verificación
        mockMvc.perform(post("/api/pedidos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedidoInvalido)))
                .andExpect(status().isBadRequest());
    }
}

