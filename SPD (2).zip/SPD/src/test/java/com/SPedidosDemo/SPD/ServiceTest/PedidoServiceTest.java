package com.SPedidosDemo.SPD.ServiceTest;


import com.SPedidosDemo.SPD.Model.PedidoModel;
import com.SPedidosDemo.SPD.Repository.PedidoRepository;
import com.SPedidosDemo.SPD.Service.PedidoService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PedidoServiceTest {

    @InjectMocks
    private PedidoService pedidoService;

    @Mock
    private PedidoRepository pedidoRepository;

    private PedidoModel pedidoEjemplo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        pedidoEjemplo = new PedidoModel();
        pedidoEjemplo.setId(1L);
        pedidoEjemplo.setCodigoSeguimiento("ABC123");
        pedidoEjemplo.setEstado(PedidoService.RECIBIDO);
        pedidoEjemplo.setClienteId("123");
    }

    @Test
    void testCrearPedido_nuevoPedido_guardadoCorrectamente() {
        when(pedidoRepository.existsByCodigoSeguimiento("ABC123")).thenReturn(false);
        when(pedidoRepository.save(any())).thenReturn(pedidoEjemplo);

        PedidoModel resultado = pedidoService.crearPedido(pedidoEjemplo);

        assertNotNull(resultado);
        assertEquals("RECIBIDO", resultado.getEstado()); //El método fallará si no es igual a "Recibido//"
    
        verify(pedidoRepository).save(pedidoEjemplo);
    }

    @Test
    void testBuscarPorCodigo_existe_devuelvePedido() {
        when(pedidoRepository.findByCodigoSeguimiento("ABC123"))
                .thenReturn(Optional.of(pedidoEjemplo));

        PedidoModel resultado = pedidoService.buscarPorCodigo("ABC123");

        assertEquals("ABC123", resultado.getCodigoSeguimiento());
    }

    @Test
    void testBuscarPorCodigo_noExiste_lanzaExcepcion() {
        when(pedidoRepository.findByCodigoSeguimiento("NOEXISTE"))
                .thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () ->
                pedidoService.buscarPorCodigo("NOEXISTE"));
    }

    @Test
    void testMarcarEnRuta_estadoValido_cambiaEstado() {
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(pedidoEjemplo));
        when(pedidoRepository.save(any())).thenReturn(pedidoEjemplo);

        PedidoModel actualizado = pedidoService.marcarEnRuta(1L);

        assertEquals(PedidoService.EN_RUTA, actualizado.getEstado());
    }

    @Test
    void testListarPorEstado_devuelveLista() {
        when(pedidoRepository.findByEstado("RECIBIDO"))
                .thenReturn(List.of(pedidoEjemplo));

        List<PedidoModel> lista = pedidoService.listarPorEstado("RECIBIDO");

        assertFalse(lista.isEmpty());
        assertEquals("RECIBIDO", lista.get(0).getEstado());
    }
}


