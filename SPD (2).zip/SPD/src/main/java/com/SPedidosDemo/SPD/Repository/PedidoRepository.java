package com.SPedidosDemo.SPD.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.query.Param;
import com.SPedidosDemo.SPD.Model.PedidoModel;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

@Schema(description = "Repositorio para operaciones de base de datos relacionadas con pedidos")
public interface PedidoRepository extends JpaRepository<PedidoModel, Long> {

    @Operation(summary = "Buscar pedido por código de seguimiento",
               description = "Retorna un pedido opcional basado en su código único de seguimiento")
    Optional<PedidoModel> findByCodigoSeguimiento(
            @Parameter(description = "Código único de seguimiento del pedido", example = "PED-12345") 
            String codigoSeguimiento);

    @Operation(summary = "Verificar existencia por código de seguimiento",
               description = "Comprueba si existe un pedido con el código de seguimiento dado")
    boolean existsByCodigoSeguimiento(
            @Parameter(description = "Código de seguimiento a verificar", example = "PED-12345") 
            String codigoSeguimiento);

    @Operation(summary = "Listar pedidos por estado",
               description = "Obtiene todos los pedidos que coinciden con el estado proporcionado")
    List<PedidoModel> findByEstado(
            @Parameter(description = "Estado del pedido (RECIBIDO, EN_RUTA, etc.)", example = "RECIBIDO") 
            String estado);

    @Operation(summary = "Listar pedidos por ID de cliente",
               description = "Recupera todos los pedidos asociados a un cliente específico")
    List<PedidoModel> findByClienteId(
            @Parameter(description = "ID único del cliente", example = "CLI-67890") 
            String clienteId);

    @Operation(summary = "Listar pedidos por cliente y estado",
               description = "Filtra pedidos por ID de cliente y estado específico")
    List<PedidoModel> findByClienteIdAndEstado(
            @Parameter(description = "ID del cliente", example = "CLI-67890") 
            String clienteId,
            
            @Parameter(description = "Estado del pedido", example = "ENTREGADO") 
            String estado);

    @Operation(summary = "Buscar pedidos entre fechas",
               description = "Consulta pedidos creados dentro de un rango de fechas específico")
    @Query("SELECT p FROM PedidoModel p WHERE p.fechaCreacion BETWEEN :inicio AND :fin")
    List<PedidoModel> findPedidosEntreFechas(
            @Param("inicio") 
            @Parameter(description = "Fecha de inicio (formato ISO)", example = "2024-01-01T00:00:00") 
            LocalDateTime inicio,
            
            @Param("fin") 
            @Parameter(description = "Fecha de fin (formato ISO)", example = "2024-12-31T23:59:59") 
            LocalDateTime fin);

    @Operation(summary = "Conteo de pedidos por estado",
               description = "Agrupa pedidos por estado y devuelve conteos")
    @Query("SELECT p.estado, COUNT(p) FROM PedidoModel p GROUP BY p.estado")
    List<Object[]> contarPedidosPorEstado();
}


