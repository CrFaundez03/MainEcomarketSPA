package com.SPedidosDemo.SPD.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.SPedidosDemo.SPD.Model.PedidoModel;
import com.SPedidosDemo.SPD.Service.PedidoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/pedidos")
@Tag(name = "Gestión de Pedidos", description = "Operaciones para gestionar el ciclo de vida de pedidos")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @Operation(summary = "Crear un nuevo pedido")
    @PostMapping
    public PedidoModel crearPedido(@RequestBody PedidoModel pedido) {
        return pedidoService.crearPedido(pedido);
    }

    @Operation(summary = "Marcar un pedido como EN_RUTA")
    @PatchMapping("/{id}/tomar-pedido")
    public PedidoModel tomarPedido(@PathVariable Long id) {
        return pedidoService.marcarEnRuta(id);
    }

    @Operation(summary = "Marcar un pedido como EN_DESTINO")
    @PatchMapping("/{id}/llegar-destino")
    public PedidoModel llegarDestino(@PathVariable Long id) {
        return pedidoService.marcarEnDestino(id);
    }
    @Operation(summary = "Confirmar entrega de un pedido (ENTREGADO)")
    @PatchMapping("/{id}/confirmar-entrega")
    public PedidoModel confirmarEntrega(@PathVariable Long id) {
        return pedidoService.marcarEntregado(id);
    }

    @Operation(summary = "Rechazar un pedido en destino (RECHAZADO)")
    @PatchMapping("/{id}/rechazar-pedido")
    public PedidoModel rechazarPedido(@PathVariable Long id) {
        return pedidoService.marcarRechazado(id);
    }

    @Operation(summary = "Buscar pedido por código de seguimiento")
    @GetMapping("/{codigoSeguimiento}")
    public PedidoModel buscarPorCodigo(@PathVariable String codigoSeguimiento) {
        return pedidoService.buscarPorCodigo(codigoSeguimiento);
    }

    @Operation(summary = "Listar pedidos por estado")
    @GetMapping("/estado/{estado}")
    public List<PedidoModel> listarPorEstado(@PathVariable String estado) {
        return pedidoService.listarPorEstado(estado);
    }

    @Operation(summary = "Listar pedidos por ID del cliente")
    @GetMapping("/cliente/{clienteId}")
    public List<PedidoModel> listarPorCliente(@PathVariable String clienteId) {
        return pedidoService.listarPorCliente(clienteId);
    }
}
