package com.SPedidosDemo.SPD.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.SPedidosDemo.SPD.Model.PedidoModel;
import com.SPedidosDemo.SPD.Repository.PedidoRepository;

@Service
@Transactional
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    public static final String RECIBIDO = "RECIBIDO";
    public static final String EN_RUTA = "EN_RUTA";
    public static final String EN_DESTINO = "EN_DESTINO";
    public static final String ENTREGADO = "ENTREGADO";
    public static final String RECHAZADO = "RECHAZADO";

    /**
 * Crea un nuevo pedido, validando que el código de seguimiento sea único y establece su estado como RECIBIDO.
 */
    public PedidoModel crearPedido(PedidoModel pedido) {
        if (pedidoRepository.existsByCodigoSeguimiento(pedido.getCodigoSeguimiento())) {
            throw new RuntimeException("El código de seguimiento ya existe");
        }
        pedido.setEstado(RECIBIDO);
        return pedidoRepository.save(pedido);
    }


    /**
 * Cambia el estado del pedido a EN_RUTA, validando que su estado actual sea RECIBIDO.
 */
    public PedidoModel marcarEnRuta(Long id) {
        PedidoModel pedido = obtenerPedido(id);
        validarTransicion(pedido.getEstado(), RECIBIDO, "tomar para entrega");
        pedido.setEstado(EN_RUTA);
        return pedidoRepository.save(pedido);
    }

    /**
 * Cambia el estado del pedido a EN_DESTINO, validando que su estado actual sea EN_RUTA.
 */
    public PedidoModel marcarEnDestino(Long id) {
        PedidoModel pedido = obtenerPedido(id);
        validarTransicion(pedido.getEstado(), EN_RUTA, "marcar como en destino");
        pedido.setEstado(EN_DESTINO);
        return pedidoRepository.save(pedido);
    }

    /**
 * Marca el pedido como ENTREGADO, validando que su estado actual sea EN_DESTINO.
 */
    public PedidoModel marcarEntregado(Long id) {
        PedidoModel pedido = obtenerPedido(id);
        validarTransicion(pedido.getEstado(), EN_DESTINO, "confirmar entrega");
        pedido.setEstado(ENTREGADO);
        return pedidoRepository.save(pedido);
    }

    /**
 * Rechaza un pedido, cambiando su estado a RECHAZADO, solo si está en estado EN_DESTINO.
 */
    public PedidoModel marcarRechazado(Long id) {
        PedidoModel pedido = obtenerPedido(id);
        validarTransicion(pedido.getEstado(), EN_DESTINO, "rechazar el pedido");
        pedido.setEstado(RECHAZADO);
        return pedidoRepository.save(pedido);
    }

    /**
 * Busca un pedido por su código de seguimiento; lanza excepción si no existe.
 */
    public PedidoModel buscarPorCodigo(String codigoSeguimiento) {
        return pedidoRepository.findByCodigoSeguimiento(codigoSeguimiento)
                .orElseThrow(() -> new RuntimeException("No se encontró el pedido"));
    }

    /**
 * Retorna una lista de pedidos filtrados por su estado (ej: "RECIBIDO", "ENTREGADO").
 */
    public List<PedidoModel> listarPorEstado(String estado) {
        return pedidoRepository.findByEstado(estado);
    }

   /**
 * Retorna una lista de pedidos asociados a un cliente específico (ID).
 */
    public List<PedidoModel> listarPorCliente(String clienteId) {
        return pedidoRepository.findByClienteId(clienteId);
    }

    /**
 * Método interno para obtener un pedido por ID; lanza excepción si no se encuentra.
 */
    private PedidoModel obtenerPedido(Long id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
    }

    /**
 * Valida que el estado actual del pedido coincida con el requerido para realizar una acción.
 */
    private void validarTransicion(String actual, String requerido, String accion) {
        if (!requerido.equals(actual)) {
            throw new IllegalStateException("Solo pedidos con estado " + requerido + " pueden " + accion);
        }
    }
}
